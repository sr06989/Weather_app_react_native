import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Text } from 'react-native-paper';
import WeatherApp from "./src/components/WeatherApp.js";


export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}> Weather App</Text>
      <WeatherApp />
    </View>
  );
}

const styles = StyleSheet.create({
    title:{
      fontSize: 20,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginLeft: 100,
      padding: 10,

    }, 
    container: {
        flex: 1,
        padding: 10,
        paddingBottom: 4,
        paddingTop: 70,
        alignItems: "stretch",
        justifyContent: "flex-start"
    },
  });
  
  
