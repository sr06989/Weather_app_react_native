import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity  } from 'react-native';
import { TextInput, Button, Card } from 'react-native-paper';
import { StyleSheet } from "react-native"
import { ScrollView } from 'react-native';


// component which gives option to add favorite cities, so that we can have them on quick access. 
function FavoriteCities({ favoriteCities, setFavoriteCities, handlePress }) {
    const [cityToAdd, setCityToAdd] = useState('');
    
    const handleAddCity = () => {
      if (cityToAdd && !favoriteCities.includes(cityToAdd)) {
        setFavoriteCities([...favoriteCities, cityToAdd]);
        setCityToAdd('');
      }
    };
    // option to remove the cities from fav cities list
    const handleRemoveCity = (cityToRemove) => {
      setFavoriteCities(favoriteCities.filter(city => city !== cityToRemove));
    };
  
    return (
        // here we have the input for adding the fav cities, in the card the fav cities are shown. 
        // then also we the option to remove the fav cities from the list. 
        <ScrollView>
        <View style={styles.addCity}>
        <View style={styles.inputContainer}>
            <TextInput
            label="Add city"
            value={cityToAdd}
            onChangeText={text => setCityToAdd(text)}
            style={styles.input}
            />
        </View>
        <Button mode="contained" onPress={handleAddCity} style={styles.addButton}>
            Add Favorite City
        </Button>
        </View>
  
        <Card>
        <Card.Title title="Favorite Cities" titleStyle={{ fontWeight: 'bold', textAlign: 'center' }} />
  <Card.Content>
    <View style={styles.favoriteCities}>
      {favoriteCities.map(city => (
        <View style={styles.favoriteCityContainer} key={city}>
          <TouchableOpacity onPress={() => handlePress(city)}>
            <Text style={styles.favoriteCity}>{city}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleRemoveCity(city)}>
            <Text style={styles.removeCity}>x</Text>
          </TouchableOpacity>
        </View>
      ))}
    </View>
  </Card.Content>
</Card>
        </ScrollView>
    );
  }


// here is the styling for the fav city component. 
  const styles = StyleSheet.create({
    sectionTitle: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 10,
      marginLeft: 100,
    },
    favoriteCities: {
      flexDirection: 'column',
      
    },
    favoriteCity: {
      fontSize: 18,
      paddingVertical: 5,
      
    },
    favoriteCityContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 10,
        marginLeft: 15,
      },
    removeCity: {
        fontSize: 20,
        color: 'red',
        marginRight: 15,
    },
    addCity: {
        marginTop: 20,
        flexDirection: 'column',
        alignItems: 'center',
      },
    inputContainer: {
        width: '80%',
        backgroundColor: 'white',
        borderRadius: 5,
        padding: 5,
        marginBottom: 10,
      },
    input: {
        width: '100%',
      },
    addButton: {
        width: '80%',
        marginBottom: 20,
        
      },
      
  });
  
export default FavoriteCities;



  