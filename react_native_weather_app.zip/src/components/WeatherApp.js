import React, { useState, useEffect } from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import { TextInput, Button, Card } from 'react-native-paper';
import { StyleSheet } from "react-native"
import FavoriteCities from './FavoriteCities';
import { ScrollView } from 'react-native';

export default function App() {
  const [city, setCity] = useState('');
  const [loading, setLoading] = useState(false); //for load, so user doesn't send mutliple response
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState(null);
  const [weatherFetched, setWeatherFetched] = useState(false); //state for fetching weather response
  const [lastSearchedCity, setLastSearchedCity] = useState('');
  const [tempUnit, setTempUnit] = useState('celsius'); // default to Celsius
  const [favoriteCities, setFavoriteCities] = useState([]); //here we use this for setting favorite cities. 

  //fetching weather response from the API and then displaying it
  const fetchWeatherData = (city) => {
    setLoading(true);
    setWeather(null);
    setError(null);
    setWeatherFetched(false);
    //checking
    console.log("Fetching weather data for", city);

    if (!city) {
      setLoading(false);
      setError("Please enter a city name");
      return;
    }
    const units = tempUnit === 'celsius' ? 'metric' : 'imperial';

    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=b7f4fe4766a2e3d176dd64da92a271ad&units=metric`)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Invalid city name, no response from server, Try again!"); //if user enters invalid city name
        }
        return response.json();
      })
      .then((data) => {
        setLoading(false); //error handling
        console.log("Weather data received", data);

        if (data.cod === 200) {
          setWeather(data.main);
          setLastSearchedCity(city);
          setWeatherFetched(true);
        } else {
          setError("Invalid city name");
        }
      })
      .catch((error) => {
        setLoading(false);
        setError(error.message);
        console.log("Error fetching weather data", error);
      });
  };

  const handlePress = () => {
    fetchWeatherData(city); //for fetching response 
  
  };


  const handle_Press = (city) => {
    fetchWeatherData(city); //for fetching response for fav city 
  };
  

  const handleRefresh = () => {
    fetchWeatherData(lastSearchedCity); //refresh the response and fetch weather data again. 
  };


  //for weather conversion from celsius to Farenheit 
  const convertCelsiusToFahrenheit = (celsius) => {
    const fahrenheit = (celsius * 9/5) + 32;
    return fahrenheit.toFixed(2);
  };
  



  return (
    <ScrollView>
  <TextInput    //taking Input here, for city name
    label="Enter city name"
    value={city}
    onChangeText={text => {
      setCity(text);
      setWeatherFetched(false);
    }}
  />
  {/* handle the loading part, card in made which displays the weather info and aldo has the feature of refresh and swtiching from Celius to F and vice a versa.*/}
  <Button mode="contained" style={styles.btn} onPress={handlePress} disabled={loading}>   
    {loading ? <ActivityIndicator animating={true} color="white" /> : "Get Weather"}
  </Button> 
  {error ? <Text style={{ color: 'red' }}>{error}</Text> : null}
  {weather && weatherFetched ? (
    <Card variant="outlined" elevation={5} style={{ marginTop: 20 }}>
      <Card.Title title={lastSearchedCity} />
      <Card.Content>
        <Text>Temperature: {tempUnit === 'celsius' ? `${weather.temp} °C` : `${convertCelsiusToFahrenheit(weather.temp)} °F`}</Text>
        <Text>Feels like: {tempUnit === 'celsius' ? `${weather.feels_like} °C` : `${convertCelsiusToFahrenheit(weather.feels_like)} °F`}</Text>
        <Text>Minimum temperature: {tempUnit === 'celsius' ? `${weather.temp_min} °C` : `${convertCelsiusToFahrenheit(weather.temp_min)} °F`}</Text>
        <Text>Maximum temperature: {tempUnit === 'celsius' ? `${weather.temp_max} °C` : `${convertCelsiusToFahrenheit(weather.temp_max)} °F`}</Text>
        <Text>Pressure: {weather.pressure} hPa</Text>
        <Text>Humidity: {weather.humidity} %</Text>
      </Card.Content>
      <Card.Actions>
        <Button onPress={handleRefresh}>Refresh</Button>
      </Card.Actions>
      <View style={styles.toggleContainer}>
        <Button mode="contained" onPress={() => setTempUnit(tempUnit === 'celsius' ? 'fahrenheit' : 'celsius')}>
          {tempUnit === 'celsius' ? 'Switch to Fahrenheit' : 'Switch to Celsius'}
        </Button>
      </View>
      
    </Card>
    
  ) : null}
  {/* here we have added the favorite cities component */}
  <FavoriteCities favoriteCities={favoriteCities} setFavoriteCities={setFavoriteCities} handlePress={handle_Press} />
  </ScrollView>


);
}

// styling for the page components. 
const styles = StyleSheet.create({
  btn: {
  margin: 10,
  padding: 5
  },
  toggleContainer: {
    marginTop: 10,
    alignItems: 'center',
    padding: 10
  },
  });
